<?php
/**
 * 微信/QQ浏览器屏蔽提示插件 - 仅复制版
 * 
 * @package AYUe
 * @author 阿月
 * @version 1.5
 * @link https://564y.com
 */
class AYUe_Plugin implements Typecho_Plugin_Interface
{
    /**
     * 激活插件
     */
    public static function activate()
    {
        Typecho_Plugin::factory('Widget_Archive')->beforeRender = array('AYUe_Plugin', 'checkBrowser');
    }
    
    /**
     * 禁用插件
     */
    public static function deactivate(){}
    
    /**
     * 配置面板
     */
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        // 是否启用插件
        $enable = new Typecho_Widget_Helper_Form_Element_Radio(
            'enable',
            array('1' => '启用', '0' => '禁用'),
            '1',
            '是否启用插件'
        );
        $form->addInput($enable);
        
        // 屏蔽页面标题
        $title = new Typecho_Widget_Helper_Form_Element_Text(
            'title',
            NULL,
            '浏览提示',
            '提示页面标题'
        );
        $form->addInput($title);
        
        // 提示内容
        $content = new Typecho_Widget_Helper_Form_Element_Textarea(
            'content',
            NULL,
            '检测到您正在使用微信/QQ内置浏览器访问，请复制下方链接到手机浏览器打开：',
            '提示内容'
        );
        $form->addInput($content);
        
        // 自定义图标URL
        $iconUrl = new Typecho_Widget_Helper_Form_Element_Text(
            'iconUrl',
            NULL,
            'https://564y.com/usr/uploads/2025/03/2481385912.webp',
            '自定义图标URL',
            '提示页面显示的浏览器图标'
        );
        $form->addInput($iconUrl);
        
        // 自定义CSS样式
        $customCSS = new Typecho_Widget_Helper_Form_Element_Textarea(
            'customCSS',
            NULL,
            '',
            '自定义CSS样式',
            '可以在此自定义提示页面的样式'
        );
        $form->addInput($customCSS);
    }
    
    /**
     * 个人配置面板
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}
    
    /**
     * 检测浏览器类型
     */
    public static function checkBrowser()
    {
        $options = Typecho_Widget::widget('Widget_Options')->plugin('AYUe');
        
        // 检查是否启用插件
        if ($options->enable != '1') {
            return;
        }
        
        $ua = strtolower($_SERVER['HTTP_USER_AGENT']);
        
        // 检测微信或QQ浏览器
        if (strpos($ua, 'micromessenger') !== false || strpos($ua, 'qq/') !== false) {
            self::showRedirectPage($options);
            exit;
        }
    }
    
    /**
     * 显示重定向页面
     */
    private static function showRedirectPage($options)
    {
        $currentUrl = 'https://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
        $iconUrl = $options->iconUrl ?: 'https://564y.com/usr/uploads/2025/03/2481385912.webp';
        
        header('Content-Type: text/html; charset=utf-8');
        
        echo <<<HTML
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{$options->title}</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            color: #333;
            line-height: 1.6;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        .notice-box {
            background-color: #fff;
            border-radius: 12px;
            padding: 30px;
            margin-top: 50px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            text-align: center;
        }
        h1 {
            color: #e74c3c;
            margin-top: 0;
            font-size: 24px;
            margin-bottom: 20px;
        }
        .url-box {
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 15px;
            margin: 25px 0;
            word-break: break-all;
            font-size: 15px;
            line-height: 1.5;
        }
        .btn-copy {
            display: inline-block;
            background-color: #2ecc71;
            color: white;
            padding: 12px 30px;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
            font-size: 16px;
            font-weight: 500;
            margin: 10px 0;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .btn-copy:hover {
            background-color: #27ae60;
            transform: translateY(-2px);
            box-shadow: 0 6px 8px rgba(0,0,0,0.15);
        }
        .browser-icon {
            width: 120px;
            height: 120px;
            margin: 30px auto;
            border-radius: 24px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            object-fit: cover;
        }
        .success-msg {
            color: #2ecc71;
            display: none;
            margin-top: 15px;
            font-size: 15px;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        .recommend {
            color: #7f8c8d;
            font-size: 14px;
            margin-top: 25px;
        }
        {$options->customCSS}
        
        @media (max-width: 480px) {
            .notice-box {
                padding: 20px;
                margin-top: 30px;
            }
            .btn-copy {
                width: 100%;
                padding: 12px;
            }
            .browser-icon {
                width: 100px;
                height: 100px;
                margin: 20px auto;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="notice-box">
            <h1>{$options->title}</h1>
            <p>{$options->content}</p>
            
            <div class="url-box" id="currentUrl">{$currentUrl}</div>
            
            <button class="btn-copy" onclick="copyUrl()">复制链接</button>
            
            <p class="success-msg" id="successMsg">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M20 6L9 17l-5-5"/>
                </svg>
                链接已复制，请粘贴到浏览器打开
            </p>
            
            <img src="{$iconUrl}" class="browser-icon" alt="浏览器提示">
            
            <p class="recommend">推荐使用Chrome、Safari或Edge浏览器访问</p>
        </div>
    </div>

    <script>
        function copyUrl() {
            var urlText = document.getElementById("currentUrl");
            var textArea = document.createElement("textarea");
            textArea.value = urlText.textContent;
            document.body.appendChild(textArea);
            textArea.select();
            document.execCommand("copy");
            document.body.removeChild(textArea);
            
            var successMsg = document.getElementById("successMsg");
            successMsg.style.display = "flex";
            setTimeout(function(){
                successMsg.style.display = "none";
            }, 3000);
        }
    </script>
</body>
</html>
HTML;
    }
}